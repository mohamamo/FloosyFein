package com.example.floosyfein

import android.app.*
import android.os.Bundle
import android.content.*
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.view.Gravity
import android.widget.*
import java.text.NumberFormat
import java.util.*
import kotlin.math.abs

data class Tx(val amount:Double,val type:String,val category:String,val note:String)

class MainActivity:Activity(){
    private val REQ=10
    private lateinit var balance:TextView
    private lateinit var income:TextView
    private lateinit var expense:TextView
    private lateinit var list:LinearLayout
    private val txs=mutableListOf<Tx>()
    private val prefs by lazy{getSharedPreferences("data",0)}

    override fun onCreate(b:Bundle?){
        super.onCreate(b); load()
        buildUi(); refresh()
        if(android.os.Build.VERSION.SDK_INT>=23 && checkSelfPermission("android.permission.RECORD_AUDIO")!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf("android.permission.RECORD_AUDIO"),55)
    }

    private fun buildUi(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,20,24,12)}
        val title=TextView(this).apply{text="فلوسي فين؟";textSize=30f;gravity=Gravity.CENTER}
        balance=stat(); income=stat(); expense=stat()
        val mic=Button(this).apply{text="🎙️  اتكلم وسجّل";textSize=19f;setOnClickListener{listen()}}
        val manual=Button(this).apply{text="✍️  إدخال يدوي";setOnClickListener{manualDialog()}}
        val header=TextView(this).apply{text="آخر العمليات";textSize=20f;setPadding(0,18,0,8)}
        list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        val scroll=ScrollView(this).apply{addView(list)}
        root.addView(title);root.addView(balance);root.addView(income);root.addView(expense);root.addView(mic);root.addView(manual);root.addView(header)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
    }
    private fun stat()=TextView(this).apply{textSize=19f;gravity=Gravity.CENTER;setPadding(0,6,0,6)}
    private fun listen(){
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply{
            putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ar-EG")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"ar-EG")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3)
            putExtra(RecognizerIntent.EXTRA_PROMPT,"مثال: دفعت ١٢٠ جنيه مواصلات و٣٥٠ أكل")
        }
        try{startActivityForResult(i,REQ)}catch(e:Exception){Toast.makeText(this,"التعرف على الكلام غير متاح على الجهاز",Toast.LENGTH_LONG).show()}
    }
    override fun onActivityResult(r:Int,c:Int,d:Intent?){
        super.onActivityResult(r,c,d)
        if(r==REQ&&c==RESULT_OK){
            val s=d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?:return
            reviewParsed(s)
        }
    }
    private fun reviewParsed(s:String){
        val amounts=extractAmounts(s)
        if(amounts.isEmpty()){Toast.makeText(this,"لم أتعرف على مبلغ. جرّب: دفعت ١٠٠ جنيه أكل",Toast.LENGTH_LONG).show();return}
        val incomeType=Regex("قبض|مرتب|راتب|دخل|استلمت|حوّلت لي|تحويل لي").containsMatchIn(s)
        val cat=category(s,incomeType)
        val msg=StringBuilder("النص الذي سمعته:\\n$s\\n\\n")
        amounts.forEachIndexed{i,n->msg.append("${i+1}) ${if(incomeType)"دخل" else "مصروف"} ${money(n)} جنيه — $cat\\n")}
        AlertDialog.Builder(this).setTitle("مراجعة قبل الحفظ").setMessage(msg.toString())
            .setNegativeButton("إلغاء",null).setPositiveButton("حفظ"){_,_->amounts.forEach{addTx(Tx(it,if(incomeType)"دخل" else "مصروف",cat,s))};save();refresh()}.show()
    }
    private fun extractAmounts(s:String):List<Double>{
        val re=Regex("""(?:[٠-٩]+(?:[.,][٠-٩]+)?|\d+(?:[.,]\d+)?)""")
        return re.findAll(s).mapNotNull{it.value.map{ch->if(ch in '٠'..'٩')('0'.code+(ch-'٠')).toChar() else ch}.joinToString("").replace(',','.').toDoubleOrNull()}.toList()
    }
    private fun category(s:String,income:Boolean)=if(income)"مرتب/دخل" else when{
        Regex("أكل|مطعم|طعام|غدا|غداء|عشا|عشاء|كشري|فول").containsMatchIn(s)->"أكل"
        Regex("مواصل|تاكسي|مترو|أوبر|بنزين|موتوسيكل").containsMatchIn(s)->"مواصلات"
        Regex("فاتور|كهرب|مياه|غاز|نت|إنترنت|موبايل").containsMatchIn(s)->"فواتير"
        Regex("حبر|طابع|سوبر|مشتريات|شراء").containsMatchIn(s)->"مشتريات"
        Regex("دواء|صيدلية|دكتور").containsMatchIn(s)->"صحة"
        else->"أخرى"
    }
    private fun manualDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(30,5,30,5)}
        val amount=EditText(this).apply{hint="المبلغ";inputType=2}
        val note=EditText(this).apply{hint="مثال: أكل / مواصلات / مرتب"}
        box.addView(amount);box.addView(note)
        AlertDialog.Builder(this).setTitle("إضافة حركة").setView(box).setNegativeButton("إلغاء",null)
            .setPositiveButton("حفظ"){_,_->val n=amount.text.toString().toDoubleOrNull();if(n!=null){val s=note.text.toString();val inc=Regex("مرتب|راتب|دخل|قبض").containsMatchIn(s);addTx(Tx(n,if(inc)"دخل" else "مصروف",category(s,inc),s));save();refresh()}}.show()
    }
    private fun addTx(t:Tx){txs.add(0,t)}
    private fun refresh(){
        val inc=txs.filter{it.type=="دخل"}.sumOf{it.amount};val exp=txs.filter{it.type=="مصروف"}.sumOf{it.amount}
        balance.text="الرصيد: ${money(inc-exp)} جنيه";income.text="🟢 الدخل: ${money(inc)} جنيه";expense.text="🔴 المصروف: ${money(exp)} جنيه"
        list.removeAllViews()
        txs.take(50).forEachIndexed{idx,t->
            val row=TextView(this).apply{text="${if(t.type=="دخل")"🟢" else "🔴"} ${money(t.amount)} جنيه — ${t.category}${if(t.note.isNotBlank())"\\n${t.note}" else ""}";textSize=17f;setPadding(5,12,5,12);setOnLongClickListener{confirmDelete(idx);true}}
            list.addView(row)
        }
    }
    private fun confirmDelete(i:Int){AlertDialog.Builder(this).setTitle("حذف العملية؟").setMessage("سيتم حذف العملية من السجل.").setNegativeButton("إلغاء",null).setPositiveButton("حذف"){_,_->txs.removeAt(i);save();refresh()}.show()}
    private fun save(){prefs.edit().putString("txs",txs.joinToString("|||"){"${it.amount}§${it.type}§${it.category}§${it.note.replace("§"," ")}"}).apply()}
    private fun load(){prefs.getString("txs","")?.split("|||")?.filter{it.isNotBlank()}?.forEach{p->val a=p.split("§");if(a.size>=4)a[0].toDoubleOrNull()?.let{txs.add(Tx(it,a[1],a[2],a[3]))}}}
    private fun money(x:Double)=NumberFormat.getNumberInstance(Locale("ar","EG")).apply{maximumFractionDigits=2;minimumFractionDigits=0}.format(abs(x))
}